# 云端项目日常操作

当前网站地址：http://47.111.128.252 。服务器项目目录：`/opt/order-demo`。
以下明确标注「服务器终端」与「本地 Windows PowerShell」，不要混用。

## 1. 在服务器操作数据库

在服务器终端执行：

```bash
cd /opt/order-demo
docker compose exec db sh -c 'MYSQL_PWD="$MYSQL_PASSWORD" exec mysql -u "$MYSQL_USER" "$MYSQL_DATABASE"'
```

第一条进入部署目录；第二条在运行中的 `db` 容器内打开 MySQL 命令行。
用户名、密码与库名由容器已有的环境变量提供，不需要把密码复制到聊天或命令里。
看到 `mysql>` 后，输入 SQL（每条以分号结尾）：

```sql
SHOW TABLES;
DESCRIBE orders;
SELECT * FROM orders ORDER BY id DESC LIMIT 20;
SELECT COUNT(*) AS total FROM orders;
```

分别查看表列表、订单表结构、最近 20 条订单及订单数量。
这是云端数据库，与本地 Windows 上的数据库独立。网页的增删改查会操作同一个云端库。

输入 `exit;` 退出 MySQL，回到服务器终端。
修改、删除数据前先做备份；执行 UPDATE、DELETE 时先用同样的 WHERE 条件 SELECT 确认目标行。
MySQL 的 `orders` 表使用 InnoDB，必要时可用事务核对后提交，已提交的修改不能靠退出终端撤销。

## 2. 备份云端数据库

在服务器终端、`/opt/order-demo` 目录执行：

```bash
mkdir -p backups
chmod 700 backups
umask 077
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_PASSWORD" mysqldump -u "$MYSQL_USER" --no-tablespaces --single-transaction "$MYSQL_DATABASE"' > "backups/order-demo-$(date +%F-%H%M%S).sql"
```

前三条创建只允许当前用户访问的备份目录，并限制新文件权限。
最后一条把数据库结构和数据导出为 SQL，文件名含时间。
`-T` 关闭交互终端，便于导出文件；`>` 将结果写入服务器文件。
确认命令没有报错，检查生成的 SQL 非空、包含建表内容；再通过 Workbench 下载一份留在本地。
备份可能包含客户信息，请妥善保存。

## 3. 更新前后端：推荐重新打包上传

先在本地修改并验证代码：

- React 源码：`D:\daima\reactDemoPython`。
- Python 后端：`D:\daima\agentComePython\05_mysql\demo1\crud.py`、`db.py`。

在本地 Windows PowerShell 执行：

```powershell
powershell -ExecutionPolicy Bypass -File D:\daima\agentComePython\deploy\order-demo\package.ps1
```

作用：复制最新的两个后端文件，构建 React 静态文件，再生成：

```text
D:\daima\agentComePython\deploy\order-demo.tar.gz
```

打包成功后，通过 Workbench 把新包上传到服务器 `/tmp/order-demo.tar.gz`，替换旧压缩包。
然后在服务器终端执行：

```bash
tar -xzf /tmp/order-demo.tar.gz -C /opt
cd /opt/order-demo
bash start.sh
```

第一条把部署文件覆盖到应用目录；第二条进入应用目录；第三条重新构建并更新服务。
重建服务时网站可能短暂不可用。不是每次都要重新安装 Docker。
部署包不包含 `.env` 和数据库数据，不会覆盖当前服务器的密码、网站监听地址或数据库卷。
打包脚本目前只复制 `crud.py` 和 `db.py`；后端新增模块或依赖时，需要同步修改
`package.ps1`、`make_archive.py`、`backend/Dockerfile` 或 `backend/requirements.txt` 中相关配置。

## 4. 只替换某一部分文件

代码通过 Dockerfile 的 COPY 打进镜像中，所以只替换服务器文件后，需要重新构建对应服务。
仅执行 `docker compose restart` 不会把新文件装进镜像。

### 后端

将修改后的 `crud.py`、`db.py` 上传到服务器 `/opt/order-demo/backend/`，覆盖对应文件。
保留服务器上已有的 `main.py` 和 Dockerfile，除非本次确实修改了它们。
在服务器终端执行：

```bash
cd /opt/order-demo
docker compose up -d --build --wait --wait-timeout 300 backend
```

作用：重建并更新后端，等待健康检查通过。构建期间原后端仍运行，替换容器时可能短暂中断。

### 前端

先运行上面的本地 `package.ps1`，构建产物在：

```text
D:\daima\agentComePython\deploy\order-demo\web\dist
```

把产物中的 `index.html` 和 `assets` 等完整内容上传到服务器 `/opt/order-demo/web/dist/`。
该目录下面直接是 `index.html` 和 `assets`，不要多套一层 `dist`。
不要只上传 `src`、JSX 或 TSX 源码；服务器 Nginx 使用构建后的静态文件。
在服务器终端执行：

```bash
cd /opt/order-demo
docker compose up -d --build --wait --wait-timeout 300 web
```

作用：把新静态文件打进 Nginx 镜像并更新网站服务。完成后刷新浏览器。

## 5. 每次更新后的验证

在服务器终端执行：

```bash
cd /opt/order-demo
docker compose ps
curl -fsS http://127.0.0.1/api/health
```

确认三个服务 healthy，健康接口返回 `{"status":"ok"}`；再打开网站验证本次改动。
如有异常，查看最近日志：

```bash
docker compose logs --tail=100 backend web
```

作用：查看后端和网站服务最近的日志，不会停止服务。

## 6. 数据与表结构

MySQL 数据保存在命名卷 `order-demo_mysql-data` 中，代码更新、镜像重建和通常的容器重建会保留它。
不要执行 `docker compose down -v`，该命令会删除数据库卷。
`db/init.sql` 只用于空数据库卷第一次初始化，已有数据库不会因修改此文件自动变更表结构。
新增字段、索引等需要先备份，再执行对应 SQL 迁移，并同步维护初始化脚本。
也不要直接替换 MySQL 的数据文件来导入本地数据库，应使用 SQL 导出、导入。

## 7. 用电脑上的 Navicat 管理云端 MySQL

新版部署配置将数据库端口映射到服务器的 `127.0.0.1:3307`，仅服务器本机可访问。
旧部署需要在 compose.yaml 的 db 服务下增加：

```yaml
    ports:
      - "127.0.0.1:3307:3306"
```

在服务器 `/opt/order-demo` 执行 `docker compose config --quiet` 检查配置；通过后执行
`docker compose up -d --wait --wait-timeout 300 db`，应用端口映射。
会重建数据库容器并造成短暂连接中断，数据卷保留。用 `docker compose port db 3306`
确认输出 `127.0.0.1:3307`。

在本地 Navicat 新建 MySQL 连接，常规选项填写：

| 字段 | 值 |
| --- | --- |
| 连接名 | 阿里云订单数据库 |
| 主机 | 127.0.0.1 |
| 端口 | 3307 |
| 用户名 | order_app |
| 密码 | 服务器 `/opt/order-demo/.env` 中 MYSQL_PASSWORD 的值 |

密码由用户自行从服务器复制到 Navicat，不需要发送到聊天。不要用 MYSQL_ROOT_PASSWORD。
在 SSH 选项卡勾选使用 SSH 隧道，填写：

| 字段 | 值 |
| --- | --- |
| 主机/IP | 47.111.128.252 |
| 端口 | 22 |
| 用户名 | root，或你已配置的 SSH 登录用户 |
| 验证方法 | 使用你已有的服务器登录密码或私钥 |

服务器登录密码、MySQL 密码、阿里云账号密码是不同的凭证。
Workbench 免密登录不会自动提供可供 Navicat 使用的 SSH 密码或私钥。
如果没有可用的 SSH 凭证，需要用户先在阿里云控制台配置服务器登录方式。
安全组 TCP 22 需允许自己当前公网 IP 的 `/32`；已有规则允许时无需重复添加。
不需要对公网放行 3306 或 3307。

测试连接通过后，展开 `order_demo` → 表 → `orders` 即可查看和编辑数据。
首次 SSH 连接可能需要确认服务器指纹，应与服务器实际指纹核对。
当前版本客户端若有认证兼容性错误，保留完整报错进一步处理，不要先修改数据库认证方式。

## 参考

- https://docs.docker.com/reference/cli/docker/compose/exec/
- https://docs.docker.com/reference/cli/docker/compose/up/
- https://docs.docker.com/engine/storage/volumes/
- https://www.navicat.com/en/company/aboutus/blog/1314-managing-databases-remotely-using-navicat
