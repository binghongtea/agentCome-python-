#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ -e .env ]]; then
    echo '.env already exists; keeping the current database credentials.'
    exit 0
fi
command -v openssl >/dev/null || { echo 'Install openssl first.'; exit 1; }
umask 077
{
    printf 'MYSQL_ROOT_PASSWORD=%s\n' "$(openssl rand -hex 24)"
    printf 'MYSQL_PASSWORD=%s\n' "$(openssl rand -hex 24)"
    printf 'WEB_BIND_IP=127.0.0.1\nWEB_PORT=8080\n'
} > .env
echo '.env created with random database passwords. No passwords were printed.'
