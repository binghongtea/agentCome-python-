# 阿里云 Ubuntu 24.04 部署

项目已完成首次部署。数据库查询、备份、前后端更新步骤见 [日常操作说明](OPERATIONS.md)。

适用于当前 2核2GB ECS。React 在 Windows 本地构建；服务器运行 Nginx、FastAPI 和 MySQL。
部署使用独立的新数据库，第一次没有订单，不会导入或改动本地数据库。

## 1. 登录服务器

在阿里云实例页面点击「远程连接」，选择 Workbench。
如页面提供「免密连接」，可按页面提示使用；Linux 默认用户名通常为 `root`，
如果创建时选择的是 `ecs-user`，则使用 `ecs-user`。密码由你在阿里云页面输入。

登录后先执行：

```bash
whoami
cat /etc/os-release
free -h
docker --version
docker compose version
```

新服务器上最后两条提示 command not found 是正常的，下一步安装。

## 2. 上传部署包

本地部署包：`D:\daima\agentComePython\deploy\order-demo.tar.gz`。

可用 Workbench 的文件传输功能，上传到服务器的 `/tmp`。
如果本地 SSH 已配置好，也可在 Windows PowerShell 执行下列命令，
将 `YOUR_SERVER_IP` 替换为阿里云页面显示的公网 IP：

```powershell
scp D:\daima\agentComePython\deploy\order-demo.tar.gz root@YOUR_SERVER_IP:/tmp/
```

本地 SSH 连接需要安全组允许你当前公网 IP 访问 TCP 22，并使用已配置的密码或密钥。
如果登录用户是 `ecs-user`，将上面的 `root` 改为 `ecs-user`。

上传后，在服务器终端执行（先进入 root shell，便于后续统一操作）：

```bash
sudo -i
mkdir -p /opt
tar -xzf /tmp/order-demo.tar.gz -C /opt
cd /opt/order-demo
```

## 3. 安装 Docker

查看 `install-docker.sh` 后运行：

```bash
bash install-docker.sh
```

脚本使用阿里云 Docker CE 软件包镜像，安装 Docker Engine 和 Compose 插件。
已安装且可用时会跳过安装。安装不会自动更改阿里云安全组。

软件包镜像与容器镜像仓库是两回事。本部署包使用 Docker 官方在 Amazon ECR Public
发布的 MySQL、Python 和 Nginx 基础镜像，无需 AWS 账号即可匿名拉取。
本次服务器已成功下载基础镜像、构建应用，三个服务健康检查通过，公网 HTTP 页面已可访问。
如下载失败，请保留完整错误信息，不要随意替换为未知公共镜像站。

## 4. 启动应用

```bash
cd /opt/order-demo
bash start.sh
```

脚本首次生成 `.env`，包含随机数据库密码，再构建和启动三个服务。
MySQL 健康后启动后端，后端健康后启动 Nginx。首次下载和初始化需要等待。
再次运行不会重新生成密码，不会重置数据库。

```bash
docker compose ps
curl -fsS http://127.0.0.1:8080/healthz
curl -fsS http://127.0.0.1:8080/api/health
curl -fsS -X POST 'http://127.0.0.1:8080/api/select_order?customer_name=&page=1&page_size=10'
```

正常时分别得到 `ok`、`{"status":"ok"}` 和订单数组（首次是 `[]`）。

## 5. 从自己的电脑访问

当前 CRUD 示例没有登录权限，所以部署包默认只监听服务器回环地址 `127.0.0.1:8080`。
可以先通过 SSH 隧道访问真实的云端应用。在 Windows 另开 PowerShell：

```powershell
ssh -N -L 8080:127.0.0.1:8080 root@YOUR_SERVER_IP
```

保持该窗口打开，浏览器访问 `http://127.0.0.1:8080`。
这里的前端、后端和数据库都运行在云服务器，本机只负责转发连接。
关闭隧道窗口不会停止服务器上的应用。

如要通过公网 IP 直接访问，先把阿里云安全组 TCP 80 的来源限制为你当前公网 IP 的 `/32`；
本次空数据库演示已按用户选择将来源设为 `0.0.0.0/0`，所有人均可访问并操作演示订单。
将服务器 `.env` 中 `WEB_BIND_IP` 改为 `0.0.0.0`、`WEB_PORT` 改为 `80`，并执行：

```bash
docker compose up -d --wait
```

然后用 `http://YOUR_SERVER_IP` 验证，本次地址为 `http://47.111.128.252`。
当前用于演示；正式使用应继续补登录权限、HTTPS，并按接入商要求完成公开网站相关步骤。
后端 8000 和数据库 3306 都不映射到公网，不需要放行。
为使用 Navicat，MySQL 映射到服务器回环地址 `127.0.0.1:3307`，通过 SSH 隧道访问；
安全组不用放行 3306 或 3307。连接参数见日常操作说明。

## 6. 日常操作

查看日志（Ctrl+C 退出看日志，不会停服务）：

```bash
docker compose logs --tail=100 -f
docker stats --no-stream
```

停止应用（保留数据）：

```bash
docker compose stop
```

再次启动：

```bash
docker compose up -d --wait
```

MySQL 数据存储在命名卷 `order-demo_mysql-data`。
`docker compose down` 保留命名卷；不要加 `-v`，它会删除数据库数据。
`init.sql` 只在数据库卷首次初始化时执行，后续表结构变化需要另做迁移。
应用账号和 root 密码初始化后，也不能仅通过修改 `.env` 来更换，需要在 MySQL 中同步修改。

## 7. 更新代码

在本地运行：

```powershell
powershell -ExecutionPolicy Bypass -File D:\daima\agentComePython\deploy\order-demo\package.ps1
```

脚本复制最新 `crud.py`、`db.py`，重新构建 React 并打包。
上传新的压缩包，在服务器解压到 `/opt` 后执行：

```bash
cd /opt/order-demo
docker compose up -d --build --wait --wait-timeout 300
```

部署包不包含 `.env`，更新不会覆盖服务器上的数据库密码；代码更新也不会清空数据库卷。
若修改了接口、依赖或数据库结构，应同步更新相关部署配置。

## 8. 手动备份数据库

在服务器 `/opt/order-demo` 下执行：

```bash
mkdir -p backups
chmod 700 backups
umask 077
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_PASSWORD" mysqldump -u "$MYSQL_USER" --no-tablespaces --single-transaction "$MYSQL_DATABASE"' > "backups/order-demo-$(date +%F-%H%M%S).sql"
```

备份后检查文件内容和命令结果，并保留一份到服务器外。首次学习部署时先验证手动备份，
后续再设置定时任务和保留策略。

## 当前验证范围

本地已检查前端构建、Python 语法和打包文件列表。根据本次服务器输出，MySQL、后端与
Nginx 均为 healthy，用户已确认公网 HTTP 页面可访问；后续代码更新需要重新验证。

参考：
- https://docs.docker.com/engine/install/ubuntu/
- https://help.aliyun.com/zh/ecs/user-guide/connect-to-a-linux-instance-by-using-a-password-or-key
- https://help.aliyun.com/zh/terraform/install-and-use-docker
