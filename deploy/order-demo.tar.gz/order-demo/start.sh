#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
docker compose version >/dev/null
docker info >/dev/null
bash ./init-env.sh
# Quiet validation prevents Compose from printing resolved passwords.
docker compose config --quiet
docker compose up -d --build --wait --wait-timeout 300
docker compose ps
echo 'Started. See README.md for SSH tunnel and access instructions.'
