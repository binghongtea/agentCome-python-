from fastapi import HTTPException

from crud import app
from db import get_connection


@app.get('/health', include_in_schema=False)
def health():
    conn = None
    try:
        conn = get_connection()
        with conn.cursor() as cursor:
            cursor.execute('SELECT 1')
        return {'status': 'ok'}
    except Exception:
        raise HTTPException(status_code=503, detail='Database unavailable') from None
    finally:
        if conn is not None:
            conn.close()
