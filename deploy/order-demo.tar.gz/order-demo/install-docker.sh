#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
    echo 'Run: sudo bash install-docker.sh'
    exit 1
fi
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 24.04 ]]; then
    echo 'This installation script targets Ubuntu 24.04 only.'
    exit 1
fi
if command -v docker >/dev/null && docker compose version >/dev/null 2>&1; then
    systemctl enable --now docker
    docker --version
    docker compose version
    exit 0
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl openssl
install -m 0755 -d /etc/apt/keyrings
curl --retry 3 --connect-timeout 15 -fsSL \
    https://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg \
    -o /etc/apt/keyrings/order-demo-docker.asc
chmod a+r /etc/apt/keyrings/order-demo-docker.asc
printf 'deb [arch=%s signed-by=/etc/apt/keyrings/order-demo-docker.asc] https://mirrors.aliyun.com/docker-ce/linux/ubuntu %s stable\n' \
    "$(dpkg --print-architecture)" "$VERSION_CODENAME" \
    > /etc/apt/sources.list.d/order-demo-docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker --version
docker compose version
